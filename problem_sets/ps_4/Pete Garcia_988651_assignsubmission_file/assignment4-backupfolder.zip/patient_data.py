patients = [
    ("Alan Reed", "000-00-0001", 74, "04/12/1952", 70, 218, "M"),
    ("Maria Lopez", "000-00-0002", 76, "09/03/1950", 64, 155, "F"),
    ("Robert Chen", "000-00-0003", 68, "01/19/1958", 72, 225, "M"),
    ("James Hill", "000-00-0004", 82, "11/28/1943", 69, 210, "M"),
    ("Susan Patel", "000-00-0005", 72, "06/14/1954", 65, 205, "F"),
    ("David King", "000-00-0006", 71, "02/07/1955", 71, 195, "M"),
    ("Henry Cole", "000-00-0007", 79, "08/21/1947", 68, 242, "M"),
    ("Linda Grant", "000-00-0008", 66, "12/02/1959", 63, 180, "F")
]

# Module functions

def get_patients():
    """Return all patient records."""
    return patients


def screening_rule(patient):
    """Return True if patient matches the screening rule."""

    age = patient[2]
    weight = patient[5]
    gender = patient[6]

    return gender == "M" and age > 70 and weight > 200


def display_patient(patient):
    """Display patient information."""

    print("Name:", patient[0])
    print("SSN:", patient[1])
    print("Age:", patient[2])
    print("DoB:", patient[3])
    print("Height:", patient[4], "in")
    print("Weight:", patient[5], "lb")
    print("Gender:", patient[6])