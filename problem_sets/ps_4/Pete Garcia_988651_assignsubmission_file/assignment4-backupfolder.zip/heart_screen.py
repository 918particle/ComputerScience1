import patient_data

patients = patient_data.get_patients()

print("Patients Matching Screening Rule")
print("")

for patient in patients:

    if patient_data.screening_rule(patient):

        patient_data.display_patient(patient)

        print("")